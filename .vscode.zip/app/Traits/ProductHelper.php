<?php

namespace App\Traits;

trait ProductHelper
{
    public static $badges = ['Hot', 'New', 'Sale'];
    public static $featured = ['Featured',  'Best Seller','Top Offers'];
}
