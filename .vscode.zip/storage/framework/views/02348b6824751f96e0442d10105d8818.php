
<?php $__env->startSection('content'); ?>
<!-- breadcrumb-area-start -->
<div class="breadcrumb__area pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-breadcrumb__content">
                    <div class="tp-breadcrumb__list">
                        <span class="tp-breadcrumb__active"><a href="/">Home</a></span>
                        <span class="dvdr">/</span>
                        <span>Blog</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb-area-end -->

<!-- blog-area-start -->
<section class="blog-area pt-80">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="tpblog__item tpblog__item-2 mb-20">
                    <div class="tpblog__thumb fix">
                        <a href="<?php echo e(route('blog.details',$post->slug)); ?>"><img src="<?php echo e(asset('upload/post/'.$post->image)); ?>" alt=""></a>
                    </div>
                    <div class="tpblog__wrapper">
                        <div class="tpblog__entry-wap">
                            <span class="post-data"><a href="<?php echo e(route('blog.details',$post->slug)); ?>"><?php echo e($post->created_at->format('M d Y')); ?></a></span>
                        </div>
                        <h4 class="tpblog__title"><a href="<?php echo e(route('blog.details',$post->slug)); ?>"><?php echo e(\Str::limit($post->title, 100)); ?></a></h4>
                        <p><?php echo \Str::limit($post->description, 200); ?></p>
                        <div class="tpblog__details">
                            <a href="<?php echo e(route('blog.details',$post->slug)); ?>">Continue reading <i class="icon-chevrons-right"></i> </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-12">
                <div class="basic-pagination text-center mb-80">
                    <?php if($posts->hasPages()): ?>
                    <nav>
                        <ul class="justify-content-end mb-0">
                            
                            <?php if($posts->onFirstPage()): ?>
                            <li class="page-item disabled">
                                <span class=""><i class="fa fa-angle-left"></i></span>
                            </li>
                            <?php else: ?>
                            <li>
                                <a class="" href="<?php echo e($posts->previousPageUrl()); ?>" rel="prev"><i class="fa fa-angle-left"></i></a>
                            </li>
                            <?php endif; ?>

                            
                            <?php $__currentLoopData = $posts->getUrlRange(1, $posts->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $posts->currentPage()): ?>
                            <li class=" active">
                                <span class="current"><?php echo e($page); ?></span>
                            </li>
                            <?php else: ?>
                            <li>
                                <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                            <?php if($posts->hasMorePages()): ?>
                            <li>
                                <a class="" href="<?php echo e($posts->nextPageUrl()); ?>" rel="next"><i class="fa fa-angle-right"></i></a>
                            </li>
                            <?php else: ?>
                            <li class="page-item disabled">
                                <span class=""><i class="fa fa-angle-right"></i></span>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- blog-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/frontend/blog.blade.php ENDPATH**/ ?>