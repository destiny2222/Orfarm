
<?php $__env->startSection('content'); ?>
<!-- Start Container Fluid -->
<div class="container-xxl">

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class=" d-flex justify-content-between">
                        <h4 class="card-title d-flex align-items-center gap-1">
                            <iconify-icon icon="solar:settings-bold-duotone" class="text-primary fs-20"></iconify-icon>
                            Three Banner Section
                        </h4>
                        <a href="<?php echo e(route('admin.home.bannerCreate')); ?>" class="btn btn-primary">Add new banner</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row justify-content-between g-3">
                        <div class="table-responsive">
                            <table class="table align-middle mb-0 table-hover table-centered">
                                 <thead class="bg-light-subtle">
                                      <tr>
                                           <th style="width: 20px;">
                                               S/N
                                           </th>
                                           <th>Image</th>
                                           <th>Title</th>
                                           <th>Subtitle</th>
                                           <th>Description</th>
                                           <th>Action</th>
                                      </tr>
                                 </thead>
                                 <tbody>
                                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($loop->index + 1); ?>

                                        </td>
                                        <td><img src="<?php echo e(asset('upload/banner/'.$banner->image)); ?>" width="50" height="50" alt="" ></td>
                                        <td>
                                            <?php echo e($banner->title); ?>

                                        </td>
                                        <td><?php echo e($banner->sub_title); ?></td>
                                        
                                        <td><?php echo $banner->description; ?></td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="<?php echo e(route('admin.banner.edit', $banner->id)); ?>" class="btn btn-soft-primary btn-sm"><iconify-icon icon="solar:pen-2-broken" class="align-middle fs-18"></iconify-icon></a>
                                                <a href="<?php echo e(route('admin.home.banner.delete', $banner->id)); ?>" onclick="document.getElementById('delete-banner-<?php echo e($banner->id); ?>').submit()" class="btn btn-soft-danger btn-sm"><iconify-icon icon="solar:trash-bin-minimalistic-2-broken" class="align-middle fs-18"></iconify-icon></a>
                                            </div>
                                            <form action="<?php echo e(route('admin.home.banner.delete', $banner->id)); ?>" id="delete-banner-<?php echo e($banner->id); ?>" method="post" class="d-none">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                            </table>
                       </div>
                       <!-- end table-responsive -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title d-flex align-items-center gap-1">
                        <iconify-icon icon="solar:settings-bold-duotone" class="text-primary fs-20"></iconify-icon>
                        Two Column Section
                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.home.promotion.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="meta-name" class="form-label"> Title</label>
                                    <input type="text" id="meta-name" name="title" value="<?php echo e($promotion->title ?? ''); ?>" class="form-control" placeholder="Title">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="meta-tag" class="form-label">Subtitle</label>
                                    <input type="text" id="meta-tag" name="subtitle" value="<?php echo e($promotion->subtitle ?? ''); ?>" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-12 col-lg-8">
                                        <div class="mb-3">
                                            <label for="meta-description" class="form-label">Image</label>
                                            <input type="file" name="image"  id="" value="<?php echo e($promotion->image ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="mb-3">
                                            <img src="<?php echo e(asset('upload/promotion/'.$promotion->image)); ?>" class="img-fluid" alt="" style="width: 50%; height: auto;object-fit: cover;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="meta-description" class="form-label">Description</label>
                                    <textarea class="form-control bg-light-subtle" id="meta-description" name="description" cols="30" rows="4" placeholder="Type description"><?php echo e($promotion->description ?? ''); ?></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <button type="submit"  class="btn btn-success">Save Change</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title d-flex align-items-center gap-1">
                        <iconify-icon icon="solar:shop-2-bold-duotone" class="text-primary fs-20"></iconify-icon>Two Column Section
                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.home.dealStore')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="meta-name" class="form-label"> Title</label>
                                    <input type="text" id="meta-name" name="title" value="<?php echo e($dealOfDays->title ?? ''); ?>" class="form-control" placeholder="Title">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="meta-tag" class="form-label">Subtitle</label>
                                    <input type="text" id="meta-tag" name="subtitle" value="<?php echo e($dealOfDays->subtitle ?? ''); ?>" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="">Offer time</label>
                                    <input type="date" name="offer_end_time" class="form-control" 
                                           value="<?php echo e($dealOfDays->offer_end_time ? $dealOfDays->offer_end_time->format('Y-m-d') : ''); ?>">
                                </div>
                            </div>                            
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-12 col-lg-8">
                                        <div class="mb-3">
                                            <label for="meta-description" class="form-label">Image</label>
                                            <input type="file" name="image" id="" value="<?php echo e($dealOfDays->image ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4">
                                        <div class="mb-3">
                                            <img src="<?php echo e(asset('upload/deal/'.$dealOfDays->image)); ?>" class="img-fluid" alt="" style="width: 50%; height: auto;object-fit: cover;">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="meta-description" class="form-label">Description</label>
                                    <textarea class="form-control bg-light-subtle" id="description" name="description" cols="30" rows="4"><?php echo e($dealOfDays->description ?? ''); ?></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <button type="submit"  class="btn btn-success">Save Change</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

   

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title d-flex align-items-center gap-1">
                        <iconify-icon icon="solar:box-bold-duotone" class="text-primary fs-20"></iconify-icon>Plugin Settings
                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.home.pluginStore')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="meta-name" class="form-label"> Paystack Public key</label>
                                    <input type="text" id="meta-name" name="paystack_secret" value="<?php echo e($plugins->paystack_secret ?? ''); ?>" class="form-control" placeholder="">
                                </div>
                            </div> 
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="meta-tag" class="form-label">Paystack script key</label>
                                    <input type="text" id="meta-tag" name="paystack_key" value="<?php echo e($plugins->paystack_key ?? ''); ?>" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <button type="submit"  class="btn btn-success">Save Change</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Container Fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/admin/homepage/index.blade.php ENDPATH**/ ?>