<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    // success message popup notification
    <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>");
    <?php endif; ?>

    // info message popup notification
    <?php if(Session::has('info')): ?>
        toastr.info("<?php echo e(Session::get('info')); ?>");
    <?php endif; ?>

    // warning message popup notification
    <?php if(Session::has('warning')): ?>
        toastr.warning("<?php echo e(Session::get('warning')); ?>");
    <?php endif; ?>

    // error message popup notification
    <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>");
    <?php endif; ?>
</script><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/layouts/message.blade.php ENDPATH**/ ?>