
<?php $__env->startSection('content'); ?>
<!-- Start Container Fluid -->
<div class="container-xxl">
    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title d-flex align-items-center gap-1">
                        <iconify-icon icon="solar:settings-bold-duotone" class="text-primary fs-20"></iconify-icon> Setting
                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.update.profile' , $admins->id )); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="meta-name" class="form-label"> Name</label>
                                    <input type="text" id="meta-name" name="name" value="<?php echo e($admins->name ?? ''); ?>" class="form-control" placeholder="Title">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label for="meta-tag" class="form-label">Email</label>
                                    <input type="text" id="meta-tag" name="email" value="<?php echo e($admins->email ?? ''); ?>" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <label for="">Phone</label>
                                    <input type="text" value="<?php echo e($admins->phone ?? ''); ?>" class="form-control" name="phone">
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col-12 col-lg-12">
                                        <div class="mb-3">
                                            <label for="meta-description" class="form-label">Profile picture</label>
                                            <input type="file" name="image" id="" value="<?php echo e($admins->image ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="mb-3">
                                    <button type="submit" class="btn btn-success w-100">Save Change</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title d-flex align-items-center gap-1">
                        <iconify-icon icon="solar:settings-bold-duotone" class="text-primary fs-20"></iconify-icon> Change Password
                    </h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.change.password.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="mb-3 col-md-12">
                                <label for="email" class="form-label">New Password</label>
                                <input class="form-control" type="password" name="new_password" />
                            </div>
                            <div class="mb-3 col-md-12">
                                <label for="email" class="form-label">Repeat New Password</label>
                                <input class="form-control" type="password" name="confirm_password" placeholder="" />
                            </div>
                        </div>
                        <div class="mt-2">
                            <input type="submit" class="btn btn-success me-2 w-100" value="Save Change">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/admin/settings.blade.php ENDPATH**/ ?>