
<?php $__env->startSection('content'); ?>
<!-- breadcrumb-area-start -->
<div class="breadcrumb__area pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-breadcrumb__content">
                    <div class="tp-breadcrumb__list">
                        <span class="tp-breadcrumb__active"><a href="index.html">Home</a></span>
                        <span class="dvdr">/</span>
                        <span>FAQs</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb-area-end -->

<!-- faq-area-start -->
<section class="faq-area pb-80 pt100">
    <div class="container">
        <div class="row justify-content-center ">
            <div class="col-lg-10">
                <div class="tpfaq">
                    <div class="tpfaq__item mb-45">
                        <h4 class="tpfaq__title mb-40">How can we help you?</h4>
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion" id="accordionPanelsStayOpenExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne-<?php echo e($faq->id); ?>" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne-<?php echo e($faq->id); ?>">
                                        <?php echo e($faq->title); ?>

                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseOne-<?php echo e($faq->id); ?>" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
                                    <div class="accordion-body">
                                        <?php echo $faq->description; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- faq-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/frontend/faq.blade.php ENDPATH**/ ?>