
<?php $__env->startSection('content'); ?>
<!-- breadcrumb-area-start -->
<div class="breadcrumb__area pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-breadcrumb__content">
                    <div class="tp-breadcrumb__list">
                        <span class="tp-breadcrumb__active"><a href="index.html">Home</a></span>
                        <span class="dvdr">/</span>
                        <span>Wishlist</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb-area-end -->

<!-- wishlist-area-start -->
<div class="cart-area pb-80">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="table-content table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="product-thumbnail">Images</th>
                                <th class="cart-product-name">Courses</th>
                                <th class="product-price">Unit Price</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-add-to-cart">Add To Cart</th>
                                <th class="product-remove">Remove</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                            $userCart = $wishlist->product->carts->where('user_id', auth()->id())->first();
                            $subtotal = $userCart ? $wishlist->product->price * $userCart->quantity : 0;
                            ?>
                            <tr>
                                <td class="product-thumbnail">
                                    <a href="<?php echo e(route('product.details', $wishlist->product->slug)); ?>">
                                        <img src="<?php echo e(asset('storage/upload/product/'.$wishlist->product->photos->first()->image_path ?? 'default-image.jpg')); ?>" alt="">
                                    </a>
                                </td>
                                <td class="product-name">
                                    <a href="<?php echo e(route('product.details', $wishlist->product->slug)); ?>"><?php echo e(\Str::limit($wishlist->product->title, 50)); ?></a>
                                </td>
                                <td class="product-price">
                                    <span class="amount">&#8358;<?php echo e(number_format($wishlist->product->price, 2)); ?></span>
                                </td>
                                <form action="<?php echo e(route('wishlist.add.cart')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="product_id" value="<?php echo e($wishlist->product->id); ?>">
                                    <input type="hidden" name="slug" value="<?php echo e($wishlist->product->slug); ?>">
                                    <td class="product-quantity">
                                        <span class="cart-minus">-</span>
                                        <input class="cart-input" name="quantity" type="text" value="1">
                                        <span class="cart-plus">+</span>
                                    </td>
                                    <td class="product-add-to-cart">
                                        <button type="submit" class="tp-btn tp-color-btn tp-wish-cart banner-animation">Add To Cart</button>
                                    </td>
                                </form>
                                <td class="product-remove">
                                    <a href="<?php echo e(route('wishlist.remove', $wishlist->id )); ?>" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($wishlist->id); ?>').submit();"><i class="fa fa-times"></i></a>
                                </td>
                                <form action="<?php echo e(route('wishlist.remove', $wishlist->id )); ?>" id="delete-form-<?php echo e($wishlist->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">No items in wishlist</td>
                            </tr>
                            <?php endif; ?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- wishlist-area-end-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/frontend/wishlist.blade.php ENDPATH**/ ?>