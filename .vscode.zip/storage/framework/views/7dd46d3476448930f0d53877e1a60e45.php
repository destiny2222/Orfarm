
<?php $__env->startSection('content'); ?>
<section class=" auth">
    <div class="container">
        <div class="pb-3 row justify-content-center">

            <div class="col-12 col-md-12 col-lg-12 col-sm-12 col-xl-12">

               
                <form method="POST" action="<?php echo e(route('verification.send')); ?>" class="mt-4 login-form">
                <div class="bg-white shadow card login-page roundedd border-1 ">
                    <div class="card-body">
                        <?php if(session('status') == 'verification-link-sent'): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>
                        <p><?php echo e(__('Before proceeding, please check your email for a verification link.')); ?></p>
                        <p><?php echo e(__('If you did not receive the email')); ?>,</p>
                            <?php echo csrf_field(); ?>
                            <div class="mb-0 col-lg-12">
                                <button class="btn btn-primary btn-block pad" type="submit">
                                    <?php echo e(__('Resend Verification Email')); ?></button>
                            </div>
                            <!--end col-->
                        </form>
                    </div>
                    <!--end row-->
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="mt-4 login-form">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary btn-block pad">
                            <?php echo e(__('Log Out')); ?>

                        </button>
                    </form>


                </div>
            </div>
            <!---->
        </div>
        <!--end col-->
    </div>
    <!--end row-->
    </div>
    <!--end container-->
</section>
<!--end section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>