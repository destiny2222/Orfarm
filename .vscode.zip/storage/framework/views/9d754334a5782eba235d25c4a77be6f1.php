
<?php $__env->startSection('content'); ?>
<!-- breadcrumb-area-start -->
<div class="breadcrumb__area grey-bg pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-breadcrumb__content">
                    <div class="tp-breadcrumb__list">
                        <span class="tp-breadcrumb__active"><a href="/">Home</a></span>
                        <span class="dvdr">/</span>
                        <span>Shop</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb-area-end -->

<!-- shop-area-start -->
<section class="shop-area-start grey-bg pb-200">
    <div class="container">
        <div class="row">
            
            <div class="col-xl-12 col-lg-12 col-md-12">
                <div class="tpshop__top ml-60">
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active whight-product" id="nav-popular" role="tabpanel" aria-labelledby="nav-popular-tab">
                            <div class="row  tpproduct__shop-item">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-lg-3 col-md-6 col-sm-6">
                                    <div class="tpproduct p-relative mb-20">
                                        <div class="tpproduct__thumb p-relative text-center">
                                            <a href="<?php echo e(route('product.details', $product->slug)); ?>"><img src="<?php echo e(asset('storage/upload/product/'.$product->photos->first()->image_path)); ?>" alt=""></a>
                                            <a class="tpproduct__thumb-img" href="<?php echo e(route('product.details', $product->slug)); ?>"><img src="<?php echo e(asset('storage/upload/product/'.$product->photos->first()->image_path)); ?>" alt=""></a>
                                            <div class="tpproduct__info bage">
                                                <span class="tpproduct__info-discount bage__discount"><?php echo e(App\Models\Product::calculateDiscount($product->price, $product->discount)); ?>%</span>
                                                <span class="tpproduct__info-hot bage__hot"><?php echo e($product->badge); ?></span>
                                            </div>
                                            <div class="tpproduct__shopping">
                                                <a class="tpproduct__shopping-wishlist" onclick="event.preventDefault(); document.getElementById('wish-<?php echo e($product->id); ?>').submit()" href="<?php echo e(route('wishlist.add')); ?>"><i class="icon-heart icons"></i></a>
                                                <form action="<?php echo e(route('wishlist.add')); ?>" id="wish-<?php echo e($product->id); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                </form>
                                                <a class="tpproduct__shopping-cart" href="<?php echo e(route('product.details', $product->slug)); ?>"><i class="icon-eye"></i></a>
                                            </div>
                                        </div>
                                        <div class="tpproduct__content">
                                            <span class="tpproduct__content-weight">
                                                <a href="<?php echo e(route('product.details', $product->slug)); ?>) }}"><?php echo e($product->category->name); ?></a>
                                            </span>
                                            <h4 class="tpproduct__title">
                                                <a href="<?php echo e(route('product.details', $product->slug)); ?>) }}"><?php echo e(\Str::limit($product->title, 50)); ?></a>
                                            </h4>
                                            <div class="tpproduct__rating mb-5">
                                                <a href="#"><i class="icon-star_outline1"></i></a>
                                                <a href="#"><i class="icon-star_outline1"></i></a>
                                                <a href="#"><i class="icon-star_outline1"></i></a>
                                                <a href="#"><i class="icon-star_outline1"></i></a>
                                                <a href="#"><i class="icon-star_outline1"></i></a>
                                            </div>
                                            <div class="tpproduct__price">
                                                <span>&#8358;<?php echo e(number_format($product->discount, 2)); ?></span>
                                                <del>&#8358;<?php echo e(number_format($product->price, 2)); ?></del>
                                            </div>
                                        </div>
                                        <div class="tpproduct__hover-text">
                                            <form action="<?php echo e(route('cart.add')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                <input type="hidden" name="slug" value="<?php echo e($product->slug); ?>">
                                                <input type="hidden" name="quantity" class="" value="1">
                                                <div class="tpproduct__hover-btn d-flex justify-content-center mb-10">
                                                    <button type="submit" class="tp-btn-2">Add to cart</button>
                                                </div>
                                            </form>
                                            
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="basic-pagination text-center mt-35">
                        <?php if($products->hasPages()): ?>
                        <nav >
                            <ul class="justify-content-end mb-0">
                                
                                <?php if($products->onFirstPage()): ?>
                                <li class="page-item disabled">
                                    <span class=""><i class="fa fa-angle-left"></i></span>
                                </li>
                                <?php else: ?>
                                <li >
                                    <a class="" href="<?php echo e($products->previousPageUrl()); ?>" rel="prev"><i class="fa fa-angle-left"></i></a>
                                </li>
                                <?php endif; ?>

                                
                                <?php $__currentLoopData = $products->getUrlRange(1, $products->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $products->currentPage()): ?>
                                <li class=" active">
                                    <span class="current"><?php echo e($page); ?></span>
                                </li>
                                <?php else: ?>
                                <li >
                                    <a  href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                </li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                
                                <?php if($products->hasMorePages()): ?>
                                <li >
                                    <a class="" href="<?php echo e($products->nextPageUrl()); ?>" rel="next"><i class="fa fa-angle-right"></i></a>
                                </li>
                                <?php else: ?>
                                <li class="page-item disabled">
                                    <span class=""><i class="fa fa-angle-right"></i></span>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- shop-area-end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/frontend/shop.blade.php ENDPATH**/ ?>