
<?php $__env->startSection('heading', 'Product List'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="row">
         <div class="col-xl-12">
              <div class="card">
                   <div class="card-header d-flex justify-content-between align-items-center gap-1">
                        <h4 class="card-title flex-grow-1">All Product List</h4>
                        <a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-sm btn-primary">
                             Add Product
                        </a>
                   </div>
                   <div>
                        <div class="table-responsive">
                             <table class="table align-middle mb-0 table-hover table-centered">
                                  <thead class="bg-light-subtle">
                                       <tr>
                                            <th style="width: 20px;">
                                                 S/N
                                            </th>
                                            <th>Image</th>
                                            <th>Product Name</th>
                                            <th>Price</th>
                                            <th>Discount</th>
                                            <th>Stock</th>
                                            <th>Category</th>
                                            
                                            <th>Description</th>
                                            <th>Action</th>
                                       </tr>
                                  </thead>
                                  <tbody>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                             <td>
                                                  <?php echo e($loop->index + 1); ?>

                                             </td>
                                             <td>
                                                  <div class="d-flex align-items-center gap-2">
                                                      <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <div class="rounded bg-light avatar-md d-flex align-items-center justify-content-center">
                                                              <img src="<?php echo e(asset('storage/upload/product/' . $image->image_path)); ?>" alt="" class="avatar-md">
                                                          </div>
                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </div>
                                              </td>
                                             <td><?php echo e($product->title); ?></td>
                                             <td><?php echo e(number_format($product->price, 2)); ?></td>
                                             <td><?php echo e(number_format($product->discount, 2)); ?></td>
                                             <td>
                                                  <p class="mb-0 text-muted"><?php echo e($product->availability); ?> Stock</p>
                                             </td>
                                             <td> <?php echo e($product->category->title); ?> </td>
                                             
                                             <td>
                                                  <?php echo \Str::limit($product->description,  100, '...'); ?>

                                             </td>
                                             <td>
                                                  <div class="d-flex gap-2">
                                                       <a href="" class="btn btn-light btn-sm"><iconify-icon icon="solar:eye-broken" class="align-middle fs-18"></iconify-icon></a>
                                                       <a href="<?php echo e(route('admin.product.edit', $product->id)); ?>" class="btn btn-soft-primary btn-sm"><iconify-icon icon="solar:pen-2-broken" class="align-middle fs-18"></iconify-icon></a>
                                                       <a href="<?php echo e(route('admin.product.delete', $product->id)); ?>" onclick="event.preventDefault(); document.getElementById('delete-<?php echo e($product->id); ?>').submit(); return confirm('Are you sure to delete this category?')" class="btn btn-soft-danger btn-sm"><iconify-icon icon="solar:trash-bin-minimalistic-2-broken" class="align-middle fs-18"></iconify-icon></a>
                                                       <form action="<?php echo e(route('admin.product.delete', $product->id)); ?>" id="delete-<?php echo e($product->id); ?>" class="d-none" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                       </form>
                                                  </div>
                                             </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </tbody>
                             </table>
                        </div>
                        <!-- end table-responsive -->
                   </div>
                   <div class="card-footer border-top">
                    <?php if($products->hasPages()): ?>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end mb-0">
                            
                            <?php if($products->onFirstPage()): ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Previous</span>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>" rel="prev">Previous</a>
                                </li>
                            <?php endif; ?>
                
                            
                            <?php $__currentLoopData = $products->getUrlRange(1, $products->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $products->currentPage()): ?>
                                    <li class="page-item active">
                                        <span class="page-link"><?php echo e($page); ?></span>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                            
                            <?php if($products->hasMorePages()): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>" rel="next">Next</a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Next</span>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
                   </div>
              </div>
         </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/admin/product/index.blade.php ENDPATH**/ ?>