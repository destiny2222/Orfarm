
<?php $__env->startSection('content'); ?>
<div class="container-xxl">
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="d-flex card-header justify-content-between align-items-center">
                    <div>
                            <h4 class="card-title">All Order List</h4>
                    </div>
                    <div class="dropdown">
                        <a href="#" class="dropdown-toggle btn btn-sm btn-outline-light rounded" data-bs-toggle="dropdown" aria-expanded="false">
                            This Month
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <!-- item-->
                            <a href="#!" class="dropdown-item">Download</a>
                            <!-- item-->
                            <a href="#!" class="dropdown-item">Export</a>
                            <!-- item-->
                            <a href="#!" class="dropdown-item">Import</a>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                            <table class="table align-middle mb-0 table-hover table-centered">
                                <thead class="bg-light-subtle">
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Created at</th>
                                        <th>Customer</th>
                                        <th>Total</th>
                                        <th>Payment Status</th>
                                        <th>Items</th>
                                        <th>Order Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            #583488/80
                                        </td>
                                        <td><?php echo e($orderItem->created_at->format('d-m-Y')); ?></td>
                                        <td>
                                            <a href="#!" class="link-primary fw-medium"><?php echo e($orderItem->order->user->name); ?></a>
                                        </td>
                                        <td> &#8358;<?php echo e(number_format($orderItem->price, 2)); ?> </td>
                                        <td> 
                                            <?php if($orderItem->order->payment_status == 'paid'): ?>
                                             <span class="badge bg-success text-light  px-2 py-1 fs-13">Paid</span>
                                            <?php elseif($orderItem->order->payment_status == 'processing'): ?>
                                             <span class="badge bg-light text-dark  px-2 py-1 fs-13">Processing</span>
                                            <?php elseif($orderItem->order->payment_status == 'unpaid'): ?>
                                             <span class="badge bg-light text-dark  px-2 py-1 fs-13">Unpaid</span>
                                            <?php else: ?>
                                             <span class="badge bg-light text-dark  px-2 py-1 fs-13">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                        <td> <?php echo e($orderItem->quantity); ?> </td>
                                        <td> 
                                             <?php if($orderItem->order->order_status == 'delivered'): ?>
                                              <span class="badge px-2 bg-success px-2 py-1 fs-13" text-capitalized="">Delivered</span>
                                             <?php elseif($orderItem->order->order_status == 'processing'): ?>
                                              <span class="badge px-2 bg-info px-2 py-1 fs-13" text-capitalized="">Out for Delivery</span>
                                             <?php elseif($orderItem->order->order_status == 'cancelled'): ?>
                                              <span class="badge px-2 bg-danger px-2 py-1 fs-13" text-capitalized="">Cancelled</span>
                                             <?php elseif($orderItem->order->order_status == 'pending'): ?>
                                              <span class="badge px-2 bg-danger px-2 py-1 fs-13" text-capitalized="">Pending</span> 
                                             <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                
                                                
                                                <a href="<?php echo e(route('admin.order.delete',$orderItem->id)); ?>" onclick="return('Are you sure you want to delete this item?') event.preventDefault(); document.getElementById('delete-form-<?php echo e($orderItem->id); ?>').submit();" class="btn btn-soft-danger btn-sm"><iconify-icon icon="solar:trash-bin-minimalistic-2-broken" class="align-middle fs-18"></iconify-icon></a>
                                                <form  class="d-none" action="<?php echo e(route('admin.order.delete',$orderItem->id)); ?>" method="post" id="delete-form-<?php echo e($orderItem->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php echo $__env->make('admin.order.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                    <?php endif; ?>
                                </tbody>
                            </table>
                    </div>
                    <!-- end table-responsive -->
                </div>
                <div class="card-footer border-top">
                    <?php if($orderItems->hasPages()): ?>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end mb-0">
                            
                            <?php if($orderItems->onFirstPage()): ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Previous</span>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($orderItems->previousPageUrl()); ?>" rel="prev">Previous</a>
                                </li>
                            <?php endif; ?>
                
                            
                            <?php $__currentLoopData = $orderItems->getUrlRange(1, $orderItems->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $orderItems->currentPage()): ?>
                                    <li class="page-item active">
                                        <span class="page-link"><?php echo e($page); ?></span>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                            
                            <?php if($orderItems->hasMorePages()): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($orderItems->nextPageUrl()); ?>" rel="next">Next</a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Next</span>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/admin/order/processing.blade.php ENDPATH**/ ?>