
<?php $__env->startSection('content'); ?>

<!-- breadcrumb-area-start -->
<div class="breadcrumb__area pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="tp-breadcrumb__content">
                    <div class="tp-breadcrumb__list">
                        <span class="tp-breadcrumb__active"><a href="index.html">Home</a></span>
                        <span class="dvdr">/</span>
                        <span>Checkout</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb-area-end -->

<!-- cart area -->
<section class="cart-area pb-80">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="table-content table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="product-thumbnail">Images</th>
                                <th class="cart-product-name">Courses</th>
                                <th class="product-price">Unit Price</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-subtotal">Total</th>
                                <th class="product-remove">Remove</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $total = 0;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                $subtotal = $cart->product->price * $cart->quantity;
                                $total += $subtotal;
                                ?>
                                <tr data-id="<?php echo e($cart->id); ?>">
                                    <td class="product-thumbnail">
                                        
                                        <a href="javascript:void()">
                                            <img src="<?php echo e(asset('storage/upload/product/'.$cart->product->photos->first()->image_path)); ?>" alt="">
                                        </a>
                                        
                                    </td>
                                    <td class="product-name">
                                        <a href="javascript:void()"><?php echo e($cart->product->title); ?></a>
                                    </td>
                                    <td class="product-price">
                                        <span class="amount">&#8358;<?php echo e(number_format($cart->product->price, 2)); ?></span>
                                    </td>
                                    <td class="product-quantity">
                                        <span class="cart-minus remove-from-cart">-</span>
                                        <input class="cart-input" class=" quantity" type="text" value="<?php echo e($cart->quantity); ?>">
                                        <span class="cart-plus update-cart">+</span>
                                    </td>
                                    <td class="product-subtotal">
                                        <span class="amount">&#8358;<?php echo e(number_format($subtotal, 2)); ?></span>
                                    </td>
                                    <td class="product-remove">
                                        <a href="<?php echo e(route('cart.destroy', $cart->id)); ?>" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($cart->id); ?>').submit();"><i class="fa fa-times"></i></a>
                                        <form action="<?php echo e(route('cart.destroy', $cart->id)); ?>"  method="post" id="delete-form-<?php echo e($cart->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6"><h2>Empty Cart</h2></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="coupon-all">
                            <div class="coupon2">
                                <a href="/product" class="tp-btn tp-color-btn banner-animation">Continue Shopping</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-end">
                    <div class="col-md-5 ">
                        <div class="cart-page-total">
                            <h2>Cart totals</h2>
                            <ul class="mb-20">
                                <li>Total <span>$<?php echo e(number_format($total)); ?></span></li>
                            </ul>
                            <a href="<?php echo e(route('checkout')); ?>" class="tp-btn tp-color-btn banner-animation">Proceed to Checkout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- cart area end-->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
 $(document).ready(function() {
    // Function to show loading state
    function showLoading($input) {
        $input.addClass('loading');
        $input.prop('disabled', true);
    }

    // Function to hide loading state
    function hideLoading($input) {
        $input.removeClass('loading');
        $input.prop('disabled', false);
    }

    // Cart Minus Event Handler
    $('.cart-minus').on('click', function() {
        var $button = $(this);
        var $quantityContainer = $button.parent();
        var $input = $quantityContainer.find('input');
        var cartId = $button.closest('tr').data('id');
        var currentVal = parseInt($input.val());

        // Prevent decrease if quantity is already 1
        if (currentVal <= 1) {
            toastr.warning('Minimum quantity is 1', 'Warning');
            return;
        }

        // Show loading state
        showLoading($input);

        $.ajax({
            url: '<?php echo e(route('cart.update')); ?>',
            method: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                id: cartId,
                action: 'decrease'
            },
            success: function(response) {
                // Hide loading state
                hideLoading($input);

                if (response.success) {
                    // Update input value
                    $input.val(response.quantity);
                    
                    // Show success toast
                    toastr.success(response.message, 'Success');

                    // Reload page or update totals
                    location.reload();
                } else {
                    // Show error toast
                    toastr.error(response.message, 'Error');
                }
            },
            error: function(xhr) {
                // Hide loading state
                hideLoading($input);

                // Parse error message
                var errorMessage = 'An unexpected error occurred';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }

                // Show error toast
                toastr.error(errorMessage, 'Error');

                // Log error for debugging
                console.error('Cart Decrease Error:', xhr.responseText);
            }
        });
    });

    // Cart Plus Event Handler
    $('.cart-plus').on('click', function() {
        var $button = $(this);
        var $quantityContainer = $button.parent();
        var $input = $quantityContainer.find('input');
        var cartId = $button.closest('tr').data('id');

        // Show loading state
        showLoading($input);

        $.ajax({
            url: '<?php echo e(route('cart.update')); ?>',
            method: 'POST',
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                id: cartId,
                action: 'increase'
            },
            success: function(response) {
                // Hide loading state
                hideLoading($input);

                if (response.success) {
                    // Update input value
                    $input.val(response.quantity);
                    
                    // Show success toast
                    toastr.success(response.message, 'Success');

                    // Reload page or update totals
                    location.reload();
                } else {
                    // Show error toast
                    toastr.error(response.message, 'Error');
                }
            },
            error: function(xhr) {
                // Hide loading state
                hideLoading($input);

                // Parse error message
                var errorMessage = 'An unexpected error occurred';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                }

                // Show error toast
                toastr.error(errorMessage, 'Error');

                // Log error for debugging
                console.error('Cart Increase Error:', xhr.responseText);
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/frontend/cart.blade.php ENDPATH**/ ?>