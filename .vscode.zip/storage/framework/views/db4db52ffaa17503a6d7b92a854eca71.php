
<?php $__env->startSection('heading', 'Customer List'); ?>
<?php $__env->startSection('content'); ?>
<!-- Start Container Fluid -->
<div class="container-xxl">

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <div class=" d-flex justify-content-between">
                        <h4 class="card-title d-flex align-items-center gap-1">
                            <iconify-icon icon="solar:settings-bold-duotone" class="text-primary fs-20"></iconify-icon>
                            Customer List
                        </h4>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row justify-content-between g-3">
                        <div class="table-responsive">
                            <table class="table align-middle mb-0 table-hover table-centered">
                                 <thead class="bg-light-subtle">
                                      <tr>
                                           <th>
                                               S/N
                                           </th>
                                           <th>Image</th>
                                           <th>Name</th>
                                           <th>Email </th>
                                           <th>Phone</th>
                                      </tr>
                                 </thead>
                                 <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($loop->index + 1); ?>

                                        </td>
                                        <td>
                                            <img src="<?php echo e(asset('profile/'.$user->image)); ?>" width="50px" height="50px" alt="">
                                        </td>
                                        <td>
                                            <?php echo e($user->name); ?>

                                        </td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <?php echo e($user->phone); ?>

                                        </td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </tbody>
                            </table>
                       </div>
                       <!-- end table-responsive -->
                    </div>
                </div>
                <div class="card-footer border-top">
                    <?php if($users->hasPages()): ?>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-end mb-0">
                            
                            <?php if($users->onFirstPage()): ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Previous</span>
                                </li>
                            <?php else: ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>" rel="prev">Previous</a>
                                </li>
                            <?php endif; ?>
                
                            
                            <?php $__currentLoopData = $users->getUrlRange(1, $users->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $users->currentPage()): ?>
                                    <li class="page-item active">
                                        <span class="page-link"><?php echo e($page); ?></span>
                                    </li>
                                <?php else: ?>
                                    <li class="page-item">
                                        <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                            
                            <?php if($users->hasMorePages()): ?>
                                <li class="page-item">
                                    <a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>" rel="next">Next</a>
                                </li>
                            <?php else: ?>
                                <li class="page-item disabled">
                                    <span class="page-link">Next</span>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
                   </div>
            </div>
        </div>
    </div>
</div>
<!-- End Container Fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\d-litefood\resources\views/admin/userManagement/index.blade.php ENDPATH**/ ?>