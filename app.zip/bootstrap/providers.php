<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FortifyServiceProvider::class,
    Unicodeveloper\Paystack\PaystackServiceProvider::class,
];
